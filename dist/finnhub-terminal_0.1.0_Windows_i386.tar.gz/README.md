# finnhub-terminal
finnhub-terminal 

![example view](./_img/pic1.png)

```
export finnhub_config=<your_config_path>
go run main.go
```
config.json:
```
{
    "apiKey": "",
    "stocks":[
        "FSLY",
        "NET", 
        "FFIV"
    ]
}
```